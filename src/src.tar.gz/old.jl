"""
This collects functions that were previously used in the code but I seem to have
replaced or otherwise abandonded. Functions that I have future plans for are
included with their related functions
"""


function qngen(n,m,σ)
   #depreciated
   nd = 2*n+1
   md = 2*m+1
   narray = fill(n,nd*md)
   karray = kron(ones(md),collect(-n:n))
   marray = kron(NFOLD .* collect(-m:m) .+ σ,ones(nd))
   σarray = fill(σ,nd*md)
   out = hcat(narray,karray,marray,σarray)
end
function qngen(j,s,m,σ)
   #depreciated
   nlist = Δlist(j,s)
   out = zeros(0,4)
   for i in 1:length(nlist)
      out = vcat(out,qngen(nlist[i],m,σ))
   end
   jlist = fill(j,size(out)[1])
   out = hcat(jlist,out)
   return out
end

function vecpadder(ns,degns,offst,nm,vtmi,vtc,vecs)
   #depreciated
   partial = Array{Float64}(undef,0,sum(degns))
   for i in 1:length(ns)
      pad = (nm - ns[i])
      zpad = zeros(Float64, pad, sum(degns))
      for v in 0:(vtc)
         temp = vecs[offst[i]+v*degns[i]+1:offst[i]+(v+1)*degns[i],:]
         temp = vcat(zpad,temp,zpad)
         partial = vcat(partial,temp)
      end
   end
   return partial
end

function greaterof(x,y)
"""
I don't remember why I needed this but it returns the greater of two input values.
"""
   if x > y
      return x
   else
      return y
   end
end
