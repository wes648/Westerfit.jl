################################################################################
############                  tracalc                   ############
################################################################################


function Tμ(q)
   q = Int(q)
   if q==-1
      return μb/√(2)
   elseif q==0
      return μa
   elseif q==1
      return -μb/√(2)
   else
      return 0.0
   end
end

function intelem(jb,nb,kb,s,j,n,k)
   q = kb-k
   out = WIGXJPF.wig6j(n,j,s,jb,nb,1)*WIGXJPF.wig3j(n,1,nb,k,q,-kb)*Tμ(q)
   if out == 0.0
      return out
   else
      out = √((2*jb+1)*(2*j+1))*(-1)^(n+s+jb+1)
      out *= √((2*nb+1)*(2*n+1))*(-1)^(n-kb-1)
      return out
   end
end
function intmat2(jb,jk,s,mcalc,σ,lenb,lenk)
   mat = zeros(Float64,lenk,lenb)
   qnb = qngen2(jb,s,mcalc,σ)
   qnk = qngen2(jk,s,mcalc,σ)
   for y in 1:lenb
   for x in 1:lenk
      @inbounds mat[x,y] = intelem(jb,qnb[y,2],qnb[y,3],s,jk,qnk[x,2],qnb[x,3])
   end
   end
   Uk = ur(jk,s,mcalc)
   Ub = ur(jb,s,mcalc)
   if σ==0
      Uk *= ut(mcalc,jk,s)
      Ub *= ut(mcalc,jb,s)
   end
   mat = Uk*mat*Ub
   return mat
end

function intmat(jb,nb,jk,nk,s,k)
   sqn = length(k)
   mat = zeros(Float64,sqn,sqn)
   for x in 1:sqn
   for y in x:sqn
      @inbounds mat[x,y] = intelem(jb,nb[y],k[y],s,jk,nk[x],k[x])
   end
   end
   return Symmetric(mat)
end
function intbuild(jmax,mcalc,jb,jk,s)
   ns = Int(jmax + s)
   nbs = Δlist(jb,s)
   nks = Δlist(jk,s)
   nbarray = kron(ones((2*mcalc+1)*(2*ns+1)),nbs[1])
   nkarray = kron(ones((2*mcalc+1)*(2*ns+1)),nks[1])
   karray = kron(ones(2*mcalc+1),collect(-ns[1]:ns[1]))
   for i in 2:length(nbs)
      nbarray = vcat(nbarray,kron(ones((2*mcalc+1)*(2*ns+1)),nbs[i]))
      nkarray = vcat(nkarray,kron(ones((2*mcalc+1)*(2*ns+1)),nks[i]))
      karray = vcat(karray,kron(ones(2*mcalc+1),collect(-ns:ns)))
   end
   mat = intmat(jb,nbarray,jk,nkarray,s,karray)
   return mat
end
function intcalc(jmax,mcalc,s)
   sjmd = (2*s+1)*(2*jmax+1)*(2*mcalc+1)
   jind = convert(Int,jmax+s)
   μmat = zeros(Float64,sjmd,sjmd,jind,jind)
   for x in 1:jind
   for y in x:jind
      μmat[:,:,x,y] = intbuild(jmax,y-s,x-s,s)
      μmat[:,:,y,x] = μmat[:,:,x,y]
   end
   end
   return μmat
end

function tracalc(nmax,s,mcalc,σ,qns,vals,vecs)
   jmax = nmax - s
   ns = Δlist(jmax,s)
   trans = zeros(Float64,0,15)
   karray = kron(ones(2*mcalc+1),collect(-ns[1]:ns[1]))
   for i in 2:length(ns)
      karray = vcat(karray,kron(ones(2*mcalc+1),collect(-ns[i]:ns[i])))
   end
   ojb = 1.5
   ojk = 0.5
   lenb = convert(Int,(2*s+1)*(2*ojb+1)*(2*mcalc+1))
   lenk = convert(Int,(2*s+1)*(2*ojk+1)*(2*mcalc+1))
   μmat = intmat2(ojb,ojk,s,mcalc,σ,lenb,lenk)
   for i in 1:length(vals)
   for j in (i+1):length(vals)
      Δj = abs(qns[j,1] - qns[i,1])
      Δk = abs(qns[j,3] - qns[i,3])
      if Δj ≤ 1
#      Δka = abs(qns[j,3] - qns[i,3])
#      if Δka ≤ 2
         jb = qns[j,1]
         jk = qns[i,1]
         lenb = convert(Int,(2*s+1)*(2*jb+1)*(2*mcalc+1))
         lenk = convert(Int,(2*s+1)*(2*jk+1)*(2*mcalc+1))
         freq = vals[j] - vals[i]
         if (jb!=ojb)||(jk!=ojk)
            μmat = intmat2(jb,jk,s,mcalc,σ,lenb,lenk)
         end
         ojb = jb
         ojk = jk
         if (freq > 0.0)&&(freq < 80.0E+03)&&(Δk ≤ 1)
            int = (transpose(vecs[1:lenk,j])*μmat*vecs[1:lenb,i])^2# *exp(vals[i]/(TK*2.083661912e+4))
            if int>INTTHRESHOLD#&&(abs(qns[j,3])==0.0)&&(abs(qns[i,3])==0.0)
               temp = [freq int vals[i]/c transpose(qns[j,:]) transpose(qns[i,:])]
               trans = vcat(trans,temp)
            end
         elseif (freq < 0.0)&&(freq > -80.0E+03)&&(Δk ≤ 1)
            int = (transpose(vecs[1:lenk,i])*μmat*vecs[1:lenb,j])^2# *exp(vals[j]/(TK*2.083661912e+4))
            if (int>INTTHRESHOLD)#&&(abs(qns[j,3])==0.0)&&(abs(qns[i,3])==0.0)
               temp = [-freq int vals[j]/c transpose(qns[i,:]) transpose(qns[j,:])]
               trans = vcat(trans,temp)
            end
         else
         end#freq if
#      else
#      end#Δka if
      else
         break
      end#Δj if
   end#i for
   end#j for
   return trans
end

function pred2lne(sim)
"""
Converts the transitions output from westersim into the line format for
   westerfit. Allows for quick test scripting
"""
   out = zeros(Float64,size(sim)[1],14)
   out[:,1:12] = sim[:,4:end]
   out[:,13] = sim[:,1]
   out[:,14] = fill(0.08,size(sim)[1])
   return out
end
